import React, { useEffect } from "react";
import { loadUIAction } from "../actions/index";
import { Navigate, useParams } from "react-router-dom";
import { connect } from "react-redux";

function LoadUserInfoComponent({ loadUIAction, tokenmintinfo }) {
  const { txnId } = useParams();
  console.log(`Inside LoadUserInfoComponent with txnId : ${txnId}`);
  useEffect(() => {
    async function loadOnRefresh() {
      loadUIAction({ txnId });
    }
    loadOnRefresh();
  }, []);

  return <Navigate to="/tokenmint/connectWallet" />;
}

const mapStateToProps = (state) => ({
  tokenmintinfo: state.tokenmintinfo,
});

export default connect(mapStateToProps, { loadUIAction })(
  LoadUserInfoComponent
);
