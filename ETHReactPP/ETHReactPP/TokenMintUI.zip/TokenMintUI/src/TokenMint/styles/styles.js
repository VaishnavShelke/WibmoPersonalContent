export const bodyStyle = {
  backgroundImage: `url(../../../public/Tokenmint.png)`,
  backgroundSize: "cover",
  backgroundRepeat: "no-repeat",
  backgroundAttachment: "fixed",
};

export const tokenMintIconUrl = "../../../public/Tokenmint.png";
