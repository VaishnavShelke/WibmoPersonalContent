package com.game.inventory.beans;

import lombok.Data;

@Data
public class TransferTokenEventResponse extends CommonDTOFields{

}
