package com.game.inventory.beans;

import lombok.Data;

@Data
public class CommonDTOFields {

	private String statusCode;
	private String statusDescription;

}