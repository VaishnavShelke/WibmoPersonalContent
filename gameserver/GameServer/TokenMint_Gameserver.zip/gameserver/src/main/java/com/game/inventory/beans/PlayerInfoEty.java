package com.game.inventory.beans;

import lombok.Data;

@Data
public class PlayerInfoEty {
	private String playerName;
	private String playerId;
	private String playerInfo;
	
}
