package com.game.inventory.beans;

import lombok.Data;

@Data
public class PlayerCredentialsBean {
	private String playerName;
	private String playerPassword;
	private String playerId;
}
