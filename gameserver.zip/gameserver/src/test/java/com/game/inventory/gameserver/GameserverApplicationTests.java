package com.game.inventory.gameserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
