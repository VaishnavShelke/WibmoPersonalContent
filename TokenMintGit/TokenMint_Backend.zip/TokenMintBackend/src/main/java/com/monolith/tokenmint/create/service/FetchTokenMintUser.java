package com.monolith.tokenmint.create.service;

import org.springframework.stereotype.Service;

import com.monolith.tokentrade.TokenMintUserInfo;

@Service
public class FetchTokenMintUser {

	public TokenMintUserInfo getTokenMintUserInfoByGameIdPlayerId(String gameId, String playerId) {
		// TODO Auto-generated method stub
		return null;
	}

}
