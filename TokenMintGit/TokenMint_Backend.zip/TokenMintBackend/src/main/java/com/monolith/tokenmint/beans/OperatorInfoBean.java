package com.monolith.tokenmint.beans;

import lombok.Data;

@Data
public class OperatorInfoBean {

	private String operatorId;
	private String operatorName;
	private String operatorAddress;
	private String ethContractId;
}
