package com.monolith.tokenmint.beans;

import lombok.Data;

@Data
public class EthWalletInfoBean {

}
