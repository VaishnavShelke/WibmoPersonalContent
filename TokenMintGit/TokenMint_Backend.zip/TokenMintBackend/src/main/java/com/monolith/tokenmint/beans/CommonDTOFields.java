package com.monolith.tokenmint.beans;

import lombok.Data;

@Data
public class CommonDTOFields {

	private String statusCode;
	private String statusDescription;

}
