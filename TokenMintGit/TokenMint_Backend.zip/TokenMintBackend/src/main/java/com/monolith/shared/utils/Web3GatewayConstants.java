package com.monolith.shared.utils;

public class Web3GatewayConstants {

	public static String RESPONSE_CODE_SUCCESS = "000";
}
