package com.monolith.shared.utils;

public class Constants {

	
	public static final String MOCK_REDIS_PROPERTY = "mock.redis";
	public static String REDIS_KEY_TOKEN_MINT = "TokenMint_TXN_" ;
}
