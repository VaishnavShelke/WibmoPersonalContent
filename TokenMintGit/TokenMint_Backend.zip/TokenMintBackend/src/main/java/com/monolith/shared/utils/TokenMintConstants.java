package com.monolith.shared.utils;


public class TokenMintConstants {

	public static String RESPONSE_CODE_SUCCESS_RESPONSE = "000";
	public static String RESPONSE_CODE_VALIDATEION_FAILED = "001";	
	public static String RESPONSE_CODE_INTERNAL_SERVER_ERROR = "002";
	public static String RESPONSE_CODE_FALIURE = "003";
	public static String SUCCESS = "SUCCESS";
	
}
