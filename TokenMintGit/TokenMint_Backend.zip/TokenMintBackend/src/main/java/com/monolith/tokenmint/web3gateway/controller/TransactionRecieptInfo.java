package com.monolith.tokenmint.web3gateway.controller;

import lombok.Data;

@Data
public class TransactionRecieptInfo {

	private String blockNumber;
	private String transactionHash;

}
