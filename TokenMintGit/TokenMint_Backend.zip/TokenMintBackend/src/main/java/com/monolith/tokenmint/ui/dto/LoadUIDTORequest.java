package com.monolith.tokenmint.ui.dto;

import lombok.Data;

@Data
public class LoadUIDTORequest {

	private String tokenMintTransactionId;

}
