package com.tokenmint.create;

import com.monolith.shared.utils.Utility;

public class TestClass02 {

	public static void main(String[] args) {
		System.out.println(Utility.UUIDToHexadecimal("0xed7b4ff2-01b0-4767-abe6-8ca9bfba864a"));
		System.out.println("0x"+Long.toHexString(Long.valueOf("20231005184225221")));
	}
}
