package com.tokenmint.create;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonolithApplicationTests {

	@Test
	void contextLoads() {
	}

}
